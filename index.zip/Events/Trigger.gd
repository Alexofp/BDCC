extends Object
class_name Trigger

const SceneAndStateHook = "SceneAndStateHook"
const EnteringRoom = "EnteringRoom"
const EnteringPlayerCell = "EnteringPlayerCell"
const TakingAShower = "TakingAShower"
const Waiting = "Waiting"
const EatingInCanteen = "EatingInCanteen"
const WorkingInMines = "WorkingInMines"
const AboutToSleepInCell = "AboutToSleepInCell"
const SleepInCell = "SleepInCell"
const WakeUpInCell = "WakeUpInCell"
const CaughtOffLimits = "CaughtOffLimits"
const CaughtStealingInGreenhouse = "CaughtStealingInGreenhouse"
const ApproachedYogaMats = "ApproachedYogaMats"
const ApproachedWeightsBench = "ApproachedWeightsBench"
const TalkingToNPC = "TalkingToNPC"
const InsideElevator = "InsideElevator"
const MasturbationSpottedGuard = "MasturbationSpottedGuard"
const MasturbationSpottedInmate = "MasturbationSpottedInmate"
const HighExposureInmateEvent = "HighExposureInmateEvent"
const CaughtOffLimitsByNurse = "CaughtOffLimitsByNurse"
const CaughtOffLimitsByEnginner = "CaughtOffLimitsByEnginner"
const PCLookingForTrouble = "PCLookingForTrouble"
const TalkingToDynamicNPC = "TalkingToDynamicNPC"
const MeetDynamicNPC = "MeetDynamicNPC"
const DefeatedDynamicNPC = "DefeatedDynamicNPC"
const AfterSexWithDefeatedDynamicNPC = "AfterSexWithDefeatedDynamicNPC"
const AfterSexWithDynamicNPCThatWon = "AfterSexWithDynamicNPCThatWon"
const HypnoEncounter = "HypnoEncounter"
const EnteringRoomWithSlave = "EnteringRoomWithSlave"
const SlaverySlutLookAtEvent = "SlaverySlutLookAtEvent"
const SlaverySlutImportantEvent = "SlaverySlutImportantEvent"
const UnconsciousPCGrabbed = "UnconsciousPCGrabbed"
const WonCaughtOffLimitsFight = "WonCaughtOffLimitsFight" # args = [npcID, CharacterType.Guard/Nurse/Engineer]
const LostCaughtOffLimitsFight = "LostCaughtOffLimitsFight" # args = [npcID, CharacterType.Guard/Nurse/Engineer]
const LostOrSurrenderedToDynamicNPC = "LostOrSurrenderedToDynamicNPC" # args = [npcID, CharacterType.Guard/Nurse/Engineer]
const CaughtOffLimitsByDynamicNPC = "CaughtOffLimitsByDynamicNPC" # args = [npcID, CharacterType.Guard/Nurse/Engineer]
